import { useState } from "react"

type MobileMenuProps = {
  variant: "home" | "movecta"
  onOpenMovecta: () => void
  onShowProjects: (projectId?: string) => void
  onShowAbout: () => void
  onScrollTo?: (id: string) => void
}

type MenuName = "projects" | "contacts" | "language"

export default function MobileMenu({
  variant,
  onOpenMovecta,
  onShowProjects,
  onShowAbout,
  onScrollTo,
}: MobileMenuProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [openMenu, setOpenMenu] = useState<MenuName | null>(null)

  const closeMenu = () => {
    setIsOpen(false)
    setOpenMenu(null)
  }

  const toggleSubmenu = (menu: MenuName) => {
    setOpenMenu((current) => (current === menu ? null : menu))
  }

  const navigate = (action: () => void) => {
    closeMenu()
    action()
  }

  const projects = [
    {
      label: "PORTAL DE AUTOATENDIMENTO MOVECTA",
      action:
        variant === "home"
          ? onOpenMovecta
          : () => onScrollTo?.("movecta-inicio"),
    },
    {
      label: "BASIC UI KIT V2.0",
      action: () => onShowProjects("basic-ui-kit"),
    },
    {
      label: "STUDYIN",
      action: () => onShowProjects("studyin"),
    },
  ]

  return (
    <>
      <button
        type="button"
        className="fixed right-8 top-6 z-[9999] flex size-10 flex-col items-end justify-center gap-[5px] md:hidden"
        aria-label={isOpen ? "Fechar menu" : "Abrir menu"}
        aria-expanded={isOpen}
        aria-controls="mobile-navigation"
        onClick={() => {
          setIsOpen((current) => !current)
          setOpenMenu(null)
        }}
      >
        <span
          className={`h-px bg-[#c4c4c4] transition-transform duration-300 ${
            isOpen ? "w-6 translate-y-[6px] rotate-45" : "w-6"
          }`}
        />
        <span
          className={`h-px w-4 bg-[#c4c4c4] transition-opacity duration-300 ${
            isOpen ? "opacity-0" : "opacity-100"
          }`}
        />
        <span
          className={`h-px bg-[#c4c4c4] transition-transform duration-300 ${
            isOpen ? "w-6 -translate-y-[6px] -rotate-45" : "w-5"
          }`}
        />
      </button>

      <div
        className={`fixed inset-0 z-[9997] bg-black/40 transition-opacity duration-300 md:hidden ${
          isOpen
            ? "pointer-events-auto opacity-100"
            : "pointer-events-none opacity-0"
        }`}
        aria-hidden="true"
        onClick={closeMenu}
      />

      <section
        id="mobile-navigation"
        className={`fixed inset-y-0 right-0 z-[9998] h-dvh w-[80vw] overflow-y-auto bg-[#1c1c1c] px-8 pb-12 pt-32 transition-transform duration-300 ease-out md:hidden ${
          isOpen
            ? "translate-x-0"
            : "pointer-events-none translate-x-full"
        }`}
        aria-label="Menu mobile"
        aria-hidden={!isOpen}
      >
        <nav
          className="flex flex-col items-start gap-7 font-['IBM_Plex_Mono:SemiBold'] text-2xl text-[#c4c4c4]"
         >
          <div className="w-full">
            <button
              type="button"
              className="flex items-center gap-3"
              aria-expanded={openMenu === "projects"}
              onClick={() => toggleSubmenu("projects")}
            >
              PROJETOS
              <span
              aria-hidden="true"
              className={`transition-transform duration-300 ${
                openMenu === "projects" ? "rotate-180" : ""
              }`}
            >
              ↓
            </span>
            </button>

            {openMenu === "projects" && (
              <div className="mt-5 ml-4 flex flex-col items-start gap-4 border-l border-[#454545] pl-4 text-lg leading-snug text-[#ababab]">
                {projects.map((project) => (
                  <button
                    key={project.label}
                    type="button"
                    className="text-left"
                    onClick={() => navigate(project.action)}
                  >
                    {project.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => navigate(onShowAbout)}
          >
            SOBRE MIM
          </button>
          
          <div className="w-full">
            <button
              type="button"
              className="flex items-center gap-3"
              aria-expanded={openMenu === "contacts"}
              onClick={() => toggleSubmenu("contacts")}
            >
              CONTATOS
              <span
                aria-hidden="true"
                className={`transition-transform duration-300 ${
                  openMenu === "contacts" ? "rotate-180" : ""
                }`}
              >
                ↓
              </span>
            </button>
          
            {openMenu === "contacts" && (
              <div className="mt-5 ml-4 flex flex-col items-start gap-4 border-l border-[#454545] pl-4 text-lg leading-snug text-[#ababab]">
                <a href="https://www.linkedin.com">LINKEDIN ↗</a>
                <a href="mailto:vinicius@example.com">EMAIL ↗</a>
                <a href="https://wa.me/">WHATSAPP ↗</a>
                <a href="#cv" onClick={closeMenu}>CV ↗</a>
              </div>
            )}
          </div>
          
          <div className="w-full">
            <button
              type="button"
              className="flex items-center gap-3"
              aria-expanded={openMenu === "language"}
              onClick={() => toggleSubmenu("language")}
            >
              IDIOMA
              <span
                aria-hidden="true"
                className={`transition-transform duration-300 ${
                  openMenu === "language" ? "rotate-180" : ""
                }`}
              >
                ↓
              </span>
            </button>
          
            {openMenu === "language" && (
              <div className="mt-5 ml-4 flex flex-col items-start gap-4 border-l border-[#454545] pl-4 text-lg leading-snug text-[#ababab]">
                <button type="button" onClick={closeMenu}>
                  PORTUGUÊS
                </button>
                <button type="button" onClick={closeMenu}>
                  ENGLISH
                </button>
              </div>
            )}
          </div>
        </nav>
      </section>
    </>
  )
}