const assetPathPrefix = "/assets"

const benchmarkRows = [
  ["Portal atual", true, true, true, true, true],
  ["DP World", true, true, true, true, true],
  ["Ecoporto", true, true, true, false, true],
  ["Sita", true, true, true, true, false],
  ["Bandeirantes Deicmar", true, true, true, true, true],
  ["Tecon", false, false, true, false, true],
] as const

const columns = [
  "Portal",
  "Redestinação",
  "Presença de carga",
  "Liberação doc.",
  "Faturamento",
  "Agendamento",
]

export default function BenchmarkTable() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[760px] border-collapse text-left">
        <thead>
          <tr>
            {columns.map((column) => (
              <th
                key={column}
                className="border-b border-[#ababab]/40 p-3 font-['Satoshi_Variable:Regular'] font-medium text-[#faf9f6]"
              >
                {column}
              </th>
            ))}
          </tr>
        </thead>

        <tbody>
          {benchmarkRows.map(([portal, ...values]) => (
            <tr key={portal}>
              <td className="border-b border-[#ababab]/40 p-3">
                {portal}
              </td>

              {values.map((value, index) => (
                <td
                  key={`${portal}-${columns[index + 1]}`}
                  className="border-b border-[#ababab]/40 p-3"
                >
                  <img
                    className="size-6"
                    src={`${assetPathPrefix}/${value ? "bbbdb.svg" : "4ad9b.svg"}`}
                    alt={
                      value ? "Disponível" : "Indisponível"
                    }
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}