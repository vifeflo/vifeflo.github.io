import { useState } from "react"
import Dropdown from "./dropdown"

type HeaderProps = {
  onOpenMovecta: () => void
  onShowAbout: () => void
  onShowProjects: (projectId?: string) => void
  onGoHome: () => void
}

type MenuName = "projects" | "contacts" | "language" | null

export default function Header({
  onOpenMovecta,
  onShowAbout,
  onShowProjects,
  onGoHome,
}: HeaderProps) {
  const [openMenu, setOpenMenu] = useState<MenuName>(null)

  const toggleMenu = (menu: Exclude<MenuName, null>) => {
    setOpenMenu((current) => (current === menu ? null : menu))
  }

  return (
    <header className="page-grid fixed inset-x-0 top-0 z-30 items-center bg-gradient-to-b from-[#1c1c1c] via-[#1c1c1c]/60 to-[#1c1c1c]/0 pt-10 pb-16 max-md:pt-6">
      <a
      href="/#inicio"
      onClick={(event) => {
        event.preventDefault()
        onGoHome()
      }}
      className="fade-in col-start-2 col-end-5 whitespace-nowrap font-['Instrument_Serif:Regular'] text-xl transition-colors hover:text-[#faf9f6]"
      style={{ animationDelay: "100ms" }}
    >
      Vinicius Florencio
    </a>

      {/* Navegação desktop */}
      <nav
        aria-label="Navegação principal"
        className="fade-in col-start-5 col-end-12 hidden items-center justify-self-end gap-10 font-['IBM_Plex_Mono:SemiBold'] text-sm text-[#ababab] md:flex"
        style={{ animationDelay: "240ms" }}
      >
        <Dropdown
          label="PROJETOS"
          isOpen={openMenu === "projects"}
          onToggle={() => toggleMenu("projects")}
        >
          <button
            type="button"
            className="dropdown-link text-left"
            onClick={() => {
              setOpenMenu(null)
              onOpenMovecta()
            }}
          >
            PORTAL DE AUTOATENDIMENTO MOVECTA
          </button>

          <button
            type="button"
            className="dropdown-link text-left"
            onClick={() => {
              setOpenMenu(null)
              onShowProjects("basic-ui-kit")
            }}
          >
            BASIC UI KIT V2.0
          </button>

          <button
            type="button"
            className="dropdown-link text-left"
            onClick={() => {
              setOpenMenu(null)
              onShowProjects("studyin")
            }}
          >
            STUDYIN
          </button>
        </Dropdown>

        <button
          className="nav-button"
          type="button"
          onClick={() => {
            setOpenMenu(null)
            onShowAbout()
          }}
        >
          SOBRE MIM
        </button>

        <Dropdown
          label="CONTATOS"
          isOpen={openMenu === "contacts"}
          onToggle={() => toggleMenu("contacts")}
        >
          <a
            className="dropdown-link"
            href="https://www.linkedin.com/in/viniciusferreiraflorencio/"
            target="_blank"
            rel="noreferrer"
          >
            LINKEDIN ↗
          </a>

          <a
            className="dropdown-link"
            href="mailto:viniciusferreiraflorencio@live.com"
          >
            EMAIL ↗
          </a>

          <a
            className="dropdown-link"
            href="https://wa.me/55139924705"
            target="_blank"
            rel="noreferrer"
          >
            WHATSAPP ↗
          </a>

          <a className="dropdown-link" href="#cv">
            CV ↗
          </a>
        </Dropdown>

        <Dropdown
          label="IDIOMA"
          isOpen={openMenu === "language"}
          onToggle={() => toggleMenu("language")}
        >
          <button
            className="dropdown-link text-left"
            type="button"
            onClick={() => setOpenMenu(null)}
          >
            PORTUGUÊS
          </button>

          <button
            className="dropdown-link text-left"
            type="button"
            onClick={() => setOpenMenu(null)}
          >
            ENGLISH
          </button>
        </Dropdown>
      </nav>
      
    </header>
  )
}