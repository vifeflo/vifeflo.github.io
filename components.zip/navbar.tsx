import type { NavbarSection } from "./types"

type NavbarProps = {
  sections: NavbarSection[]
  activeSection: string
  onNavigate: (id: string) => void
  footerVisible?: boolean
}

export default function Navbar({
  sections,
  activeSection,
  onNavigate,
  footerVisible = false,
}: NavbarProps) {
  return (
    <aside
      className={`sticky top-0 col-start-1 col-end-3 row-start-1 h-dvh self-start py-32 pl-8 max-md:hidden ${
        footerVisible ? "pointer-events-none opacity-0" : ""
      }`}
    >
      <nav
        aria-label="Navegação da página"
        className="flex flex-col gap-4"
      >
        {sections.map((section) => (
          <button
            key={section.id}
            type="button"
            onClick={() => onNavigate(section.id)}
            aria-current={
              activeSection === section.id ? "location" : undefined
            }
            className={`w-fit text-left text-sm transition-colors ${
              activeSection === section.id
                ? "text-[#faf9f6]"
                : "text-[#ababab] hover:text-[#faf9f6]"
            }`}
          >
            {section.label}
          </button>
        ))}
      </nav>
    </aside>
  )
}
