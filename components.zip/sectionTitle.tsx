import type { ReactNode } from "react"

type SectionTitleProps = {
  eyebrow?: string
  children: ReactNode
}

export default function SectionTitle({
  eyebrow,
  children,
}: SectionTitleProps) {
  return (
    <div className="flex flex-col gap-1">
      {eyebrow && (
        <p className="font-['IBM_Plex_Mono:Medium'] text-xs text-[#ababab]">
          {eyebrow}
        </p>
      )}

      <h2 className="font-['Instrument_Serif:Regular'] text-[32px] leading-none text-[#faf9f6]">
        {children}
      </h2>
    </div>
  )
}