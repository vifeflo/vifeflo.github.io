export default function DashedDivider() {
  return (
    <div
      aria-hidden="true"
      className="w-full"
      style={{
        height: "0.2px",
        backgroundImage:
          "repeating-linear-gradient(to right, #ABABAB 0px, #ABABAB 4px, transparent 4px, transparent 14px)",
      }}
    />
  )
}