export default function Divider() {
  return (
    <div
      aria-hidden="true"
      className="w-full bg-[#ABABAB]"
      style={{ height: "0.2px" }}
    />
  )
}