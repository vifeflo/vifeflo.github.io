import { useState } from "react"
import type { NavbarSection } from "./types"

type MobileNavbarProps = {
  sections: NavbarSection[]
  activeSection: string
  onNavigate: (id: string) => void
  footerVisible?: boolean
}

export default function MobileNavbar({
  sections,
  activeSection,
  onNavigate,
  footerVisible = false,
}: MobileNavbarProps) {
  const [isOpen, setIsOpen] = useState(false)

  const activeLabel =
    sections.find((section) => section.id === activeSection)?.label ??
    "Navegação"

  const handleNavigate = (id: string) => {
    onNavigate(id)
    setIsOpen(false)
  }

  return (
    <div
      className={`fixed bottom-6 left-1/2 z-40 hidden -translate-x-1/2 max-md:block ${
        footerVisible ? "pointer-events-none opacity-0" : ""
      }`}
    >
      <button
        type="button"
        onClick={() => setIsOpen((open) => !open)}
        aria-expanded={isOpen}
        className="bg-[#242424] px-5 py-3 text-sm text-[#faf9f6] shadow-xl"
      >
        {activeLabel}
        <span className="ml-2" aria-hidden="true">
          {isOpen ? "↑" : "↓"}
        </span>
      </button>

      {isOpen && (
        <nav
          aria-label="Navegação mobile"
          className="absolute bottom-full mb-2 flex max-h-[60vh] w-max min-w-full flex-col gap-4 overflow-y-auto bg-[#242424] p-5 shadow-xl"
        >
          {sections.map((section) => (
            <button
              key={section.id}
              type="button"
              onClick={() => handleNavigate(section.id)}
              aria-current={
                activeSection === section.id ? "location" : undefined
              }
              className={`text-left text-sm transition-colors ${
                activeSection === section.id
                  ? "text-[#faf9f6]"
                  : "text-[#ababab] hover:text-[#faf9f6]"
              }`}
            >
              {section.label}
            </button>
          ))}
        </nav>
      )}
    </div>
  )
}