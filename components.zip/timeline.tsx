const assetPathPrefix = "/assets"

const phases = [
  {
    name: "EMPATIA",
    duration: "3 semanas",
    description:
      "Pesquisa com usuários, análise de reclamações de CX e avaliação heurística",
    start: "0%",
    width: "16%",
    color: "bg-[#a65959]",
  },
  {
    name: "DEFINIÇÃO",
    duration: "6 semanas",
    description:
      "Mapas de afinidade e identificação de problemas na jornada",
    start: "0%",
    width: "35%",
    color: "bg-[#a69359]",
  },
  {
    name: "IDEAÇÃO",
    duration: "3 semanas",
    description:
      "Exploração de soluções, benchmarking, inventário de recursos e wireframes",
    start: "38%",
    width: "18%",
    color: "bg-[#59a659]",
  },
  {
    name: "PROTOTIPAÇÃO",
    duration: "8 semanas",
    description:
      "Protótipos navegáveis de alta fidelidade no Figma",
    start: "49%",
    width: "46%",
    color: "bg-[#5998a6]",
  },
  {
    name: "TESTES",
    duration: "6 semanas",
    description:
      "Testes moderados de usabilidade e iteração dos protótipos",
    start: "61%",
    width: "34%",
    color: "bg-[#9c59a6]",
  },
]

const months = ["JUN", "JUL", "AGO", "SET", "OUT"]

export default function Timeline() {
  return (
    <div className="bg-gradient-to-b from-[#242424] to-[#262626] p-3 shadow-[0_4px_4px_rgba(0,0,0,0.12)]">
      <p className="mb-3 text-sm font-medium">
        Linha do tempo do projeto - 20 semanas
      </p>

      <div className="grid grid-cols-[1.1fr_1fr] gap-6 max-md:grid-cols-1">
        <div className="relative grid min-h-[300px] grid-rows-5 gap-4 py-2 max-sm:min-h-[260px]">
          <div className="pointer-events-none absolute inset-y-0 left-[100px] right-0 flex justify-between max-sm:left-[84px]">
            {months.map((month) => (
              <div
                key={month}
                className="flex h-full flex-col items-center overflow-hidden"
              >
                <span className="min-h-0 flex-1 overflow-hidden">
                  <img
                    className="block max-w-none"
                    src={`${assetPathPrefix}/938ec.svg`}
                    alt=""
                  />
                </span>

                <span className="font-['IBM_Plex_Mono:Regular'] text-xs text-[#ababab]">
                  {month}
                </span>
              </div>
            ))}
          </div>

          {phases.map((phase) => (
            <div
              key={phase.name}
              className="relative z-10 grid grid-cols-[88px_1fr] items-center gap-3 max-sm:grid-cols-[72px_1fr]"
            >
              <span className="font-['IBM_Plex_Mono:Regular'] text-right text-xs text-[#ababab]">
                {phase.name}
              </span>

              <span className="relative h-1.5">
                <span
                  className={`absolute h-full shadow-md ${phase.color}`}
                  style={{
                    left: phase.start,
                    width: phase.width,
                  }}
                />
              </span>
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-3 font-['IBM_Plex_Mono:Regular'] text-xs leading-[27px]">
          {phases.map((phase, index) => (
            <div key={phase.name}>
              <p className="font-['IBM_Plex_Mono:Medium']">
                {index + 1} -{" "}
                {phase.name[0] +
                  phase.name.slice(1).toLowerCase()}{" "}
                - {phase.duration}
              </p>

              <p className="text-[#ababab]">
                {phase.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}