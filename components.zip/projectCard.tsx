const assetPathPrefix = "/assets"

export type Project = {
  id: string
  image: string
  tags: string
  title: string
  description: string
  wide?: boolean
}

type ProjectCardProps = {
  onOpen?: () => void
  project: Project
  delay: number
}

export default function ProjectCard({
  onOpen,
  project,
  delay,
}: ProjectCardProps) {
  return (
    <button
      type="button"
      id={project.id}
      className={`scroll-reveal overflow-hidden text-left shadow-[0_4px_4px_rgba(0,0,0,0.12)] ${
        project.wide ? "col-span-2 max-md:col-span-1" : ""
      }`}
      onClick={onOpen}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <img
        className={`w-full object-cover ${
          project.wide ? "aspect-[3840/1319]" : "aspect-[1200/412]"
        }`}
        src={`${assetPathPrefix}/${project.image}`}
        alt=""
      />

      <div className="flex flex-col gap-3 bg-gradient-to-b from-[#242424] to-[#262626] p-3">
        <p className="font-['IBM_Plex_Mono:Medium'] text-xs text-[#ababab]">
          {project.tags}
        </p>

        <h3 className="font-['Satoshi_Variable:Regular'] text-xl text-[#faf9f6]">
          {project.title}
        </h3>

        <p className="font-['Satoshi_Variable:Regular'] text-base text-[#c4c4c4]">
          {project.description}
        </p>
      </div>
    </button>
  )
}