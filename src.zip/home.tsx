import { useEffect, useRef, useState } from "react"
import Movecta from "./movecta"
import Header from "../components/header"
import Footer from "../components/footer"
import ProjectCard from "../components/projectCard"
import ArrowLink from "../components/arrowLink"
import MobileMenu from "../components/mobileMenu"

const assetPathPrefix = "/assets"

type MenuName = "projects" | "contacts" | "language"
type ContentView = "projects" | "about"
type PageView = "portfolio" | "movecta"

const projects = [
  {
    id: "movecta",
    image: "29fa9.png",
    tags: "2025 • RESEARCH • B2B • LOGISTICA",
    title: "Portal de Autoatendimento Movecta",
    description:
      "Redesign de um portal logístico de autoatendimento com foco em visibilidade e comunicação proativa",
    wide: true,
  },
  {
    id: "basic-ui-kit",
    image: "1fe14.png",
    tags: "BIBLIOTECA • COMPONENTES • FIGMA",
    title: "Basic UI Kit v2.0",
    description:
      "Um toolkit de design open source escalável criado para a comunidade",
  },
  {
    id: "studyin",
    image: "3f34f.png",
    tags: "MOBILE • MVP • FACULDADE",
    title: "StudyIn",
    description:
      "Um estudo sobre sistemas e componentes mobile desenvolvido durante a faculdade",
  },
]

const aboutSkills = [
  {
    title: "Prototipação",
    text: "Tenho vasta experiência em prototipação de soluções complexas de ponta a ponta, de wireframes iniciais a designs de alta fidelidade em larga escala no Figma e com uso de inteligência artificial.",
    tools: ["FIGMA 100%", "HTML5 100%", "CSS3 100%", "IA 80%"],
  },
  {
    title: "Pesquisa",
    text: "Realizo entrevistas com stakeholders e usuários finais para analisar problemas e identificar soluções, utilizando plataformas como Maze para pesquisa e validação.",
    tools: ["GA4 70%", "GTM 70%", "HOTJAR 70%", "MAZE 80%"],
  },
  {
    title: "Design system",
    text: "Crio, documento e mantenho bibliotecas de componentes escaláveis, promovendo consistência, acessibilidade e eficiência entre design e desenvolvimento.",
    tools: ["TOKENS 90%", "FIGMA 100%", "ZEROHEIGHT 80%"],
  },
  {
    title: "Mentoria",
    text: "Fui mentor de designers juniores no Processo de Formação ModalGR 2024, conduzindo rituais ágeis e gerenciando o backlog para promover o crescimento do time.",
  },
]

const experiences = [
  {
    date: "MAR 2024 - MAR 2026",
    role: "Product Designer Jr.",
    company: "MOSTEN",
    companyUrl: "https://mosten.com/",
    place: "Santos - híbrido",
    items: [
      "Criação de wireframes e protótipos interativos de baixa e alta fidelidade utilizando Figma.",
      "Condução de entrevistas, pesquisas e testes de usabilidade no Maze para validação de soluções digitais.",
      "Apoio à definição de requisitos funcionais por meio de Design Thinking e User-Centered Design.",
      "Aplicação de IA generativa na aceleração de atividades, incluindo discovery, geração de insights, mapas de afinidade, benchmarking, análise de heatmaps, arquitetura de informação e documentação técnica.",
      "Participação na criação e evolução do Design System corporativo, reduzindo em 20% o tempo médio de prototipação de novos produtos com mais de 50 componentes funcionais e documentados.",
      "Criação de documentação técnica, hospedagem e manutenção do Design System no Zeroheight e realização de handoff para equipes de desenvolvimento.",
      "Gestão do backlog com Azure DevOps (Boards, Kanban e Wiki) e condução de cerimônias Scrum.",
      "Desenvolvimento de MVPs que contribuíram para a conquista de 3 grandes clientes logísticos.",
      "Mentoria e acompanhamento técnico de designers estagiários do Programa de Formação Mosten 2024.",
    ],
  },
  {
    date: "JAN 2024 - MAR 2024",
    role: "Estagiário Front-end - WordPress",
    company: "MOSTEN",
    companyUrl: "https://mosten.com/",
    place: "Santos - híbrido",
    items: [
      "Desenvolvimento e manutenção de páginas em WordPress utilizando Elementor.",
      "Implementação de ajustes em HTML, CSS, PHP e JavaScript para interfaces responsivas.",
      "Suporte na implementação de layouts e componentes visuais.",
    ],
  },
  {
    date: "DEZ 2025 - ATUAL",
    role: "UX/UI Designer Voluntário",
    company: "ONG MOVIMENTO FUTURO",
    companyUrl: "https://movimentofuturo.org/",
    place: "São Paulo - remoto",
    items: [
      "Redesenho da página inicial com foco em usabilidade e acessibilidade digital.",
      "Criação e manutenção do Design System institucional.",
      "Documentação técnica e handoff para a equipe de desenvolvimento.",
    ],
  },
]

function AboutContent() {
  return (
    <div className="flex flex-col gap-32">
      <section className="grid grid-cols-8 gap-6 max-md:flex max-md:flex-col-reverse">
        <div className="col-span-5 flex flex-col gap-6">
          <h2 className="about-reveal scroll-reveal font-['Instrument_Serif:Regular'] text-[56px] leading-none text-[#faf9f6] max-md:text-5xl">
            Vinicius Florencio
          </h2>
          <p className="about-reveal scroll-reveal font-['Satoshi_Variable:Regular'] text-base leading-[27px]">
            Product Designer com 2 anos de experiência no desenvolvimento de
            produtos digitais B2B, especializado em pesquisas com usuários,
            testes de usabilidade, Design Systems, wireframing, prototipação
            responsiva de alta fidelidade, acessibilidade (WCAG 2.2) e mentoria
            de estagiários.
          </p>
          <p className="about-reveal scroll-reveal font-['Satoshi_Variable:Regular'] text-base leading-[27px]">
            Autodidata, desenvolvi fluência em inglês, o que me permite
            colaborar em ambientes internacionais e acompanhar as melhores
            práticas de design.
          </p>
          <div className="flex flex-wrap gap-10">
            <ArrowLink
              className="about-reveal scroll-reveal"
              href="https://www.linkedin.com"
            >
              LINKEDIN
            </ArrowLink>
            <ArrowLink
              className="about-reveal scroll-reveal"
              href="mailto:viniciusferreiraflorencio@live.com"
            >
              E-MAIL
            </ArrowLink>
            <ArrowLink
              className="about-reveal scroll-reveal"
              href="https://wa.me/5513992024705"
            >
              WHATSAPP
            </ArrowLink>
            <ArrowLink className="about-reveal scroll-reveal" href="#cv">
              CV
            </ArrowLink>
          </div>
        </div>
        <div className="col-span-3 bg-[#242424] p-3 shadow-[0_4px_4px_rgba(0,0,0,0.12)]">
          <img
            className="aspect-square w-full object-cover"
            src={`${assetPathPrefix}/e4019.png`}
            alt="Retrato de Vinicius Florencio"
          />
        </div>
      </section>

      <div className="h-px bg-[#ababab]/30" />

      <section className="flex flex-col gap-10">
        <h2 className="about-reveal scroll-reveal font-['Instrument_Serif:Regular'] text-[32px] text-[#faf9f6]">
          Competências
        </h2>
        {aboutSkills.map((skill) => (
          <article
            key={skill.title}
            className="grid grid-cols-8 gap-6 border-b border-dashed border-[#ababab]/30 pb-10 last:border-b-0 last:pb-0 max-md:flex max-md:flex-col"
          >
            <div className="col-span-5 flex flex-col gap-3">
              <h3 className="about-reveal scroll-reveal font-['Satoshi_Variable:Regular'] text-xl text-[#faf9f6]">
                {skill.title}
              </h3>
              <p className="about-reveal scroll-reveal font-['Satoshi_Variable:Regular'] text-base leading-[27px]">
                {skill.text}
              </p>
            </div>
            {skill.tools && (
              <div className="col-span-3 flex flex-col justify-end gap-3">
                {skill.tools.map((tool) => {
                  const [label, value] = tool.split(" ")
                  return (
                    <div
                      key={tool}
                      className="flex items-center gap-3 font-['IBM_Plex_Mono:Regular'] text-xs"
                    >
                      <span className="about-reveal scroll-reveal w-20 text-right">
                        {label}
                      </span>
                      <span className="h-1 flex-1 bg-[#242424]">
                        <span
                          className="skill-progress skill-reveal block h-full bg-[#c4c4c4]"
                          style={
                            {
                              "--skill-progress": value,
                            } as React.CSSProperties
                          }
                        />
                      </span>
                      <span className="about-reveal scroll-reveal w-8">
                        {value}
                      </span>
                    </div>
                  )
                })}
              </div>
            )}
          </article>
        ))}
        <div className="grid grid-cols-8 gap-6 max-md:flex max-md:flex-col">
          <article className="col-span-5 flex flex-col gap-3">
            <h3 className="about-reveal scroll-reveal text-xl text-[#faf9f6]">
              Ferramentas e tecnologias
            </h3>
            <p className="about-reveal scroll-reveal leading-[27px]">
              Figma, FigJam, Maze, Hotjar, GA4, GTM, Azure DevOps, HTML, CSS,
              JavaScript, WordPress e inteligência artificial.
            </p>
          </article>
          <article className="col-span-3 flex flex-col gap-3">
            <h3 className="about-reveal scroll-reveal text-xl text-[#faf9f6]">
              Idiomas
            </h3>
            <p className="about-reveal scroll-reveal">Português — Nativo</p>
            <p className="about-reveal scroll-reveal">
              Inglês — Fluente · C2 EF SET
            </p>
          </article>
        </div>
      </section>

      <div className="h-px bg-[#ababab]/30" />

      <section className="flex flex-col gap-10">
        <h2 className="about-reveal scroll-reveal font-['Instrument_Serif:Regular'] text-[32px] text-[#faf9f6]">
          Experiência
        </h2>
        {experiences.map((experience) => (
          <article
            key={experience.role}
            className="flex flex-col gap-3 border-b border-dashed border-[#ababab]/30 pb-10 last:border-b-0 last:pb-0"
          >
            <p className="about-reveal scroll-reveal font-['IBM_Plex_Mono:Regular'] text-xs text-[#ababab]">
              {experience.date}
            </p>
            <h3 className="about-reveal scroll-reveal text-xl text-[#faf9f6]">
              {experience.role}
            </h3>
            <p className="about-reveal scroll-reveal">
              <a
                className="font-['IBM_Plex_Mono:SemiBold'] text-sm transition-colors hover:text-[#faf9f6] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#faf9f6]"
                href={experience.companyUrl}
                target="_blank"
                rel="noreferrer"
              >
                {experience.company} ↗
              </a>{" "}
              {experience.place}
            </p>
            <ul className="list-outside list-disc space-y-1 pl-6 leading-[27px] marker:text-[#ababab]">
              {experience.items.map((item, index) => (
                <li
                  key={item}
                  className="about-reveal scroll-reveal"
                  style={{ transitionDelay: `${index * 70}ms` }}
                >
                  {item}
                </li>
              ))}
            </ul>
          </article>
        ))}
      </section>

      <div className="h-px bg-[#ababab]/30" />

      <section className="flex flex-col gap-10">
        <h2 className="about-reveal scroll-reveal font-['Instrument_Serif:Regular'] text-[32px] text-[#faf9f6]">
          Educação
        </h2>
        {[
          [
            "JUL 2024 - JUL 2026",
            "Tecnólogo em Análise e Desenvolvimento de Sistemas",
            "Universidade Santa Cecília - Santos, São Paulo",
          ],
          [
            "JUL 2023 - JUL 2024 (TRANCADO)",
            "Tecnólogo em Análise e Desenvolvimento de Sistemas",
            "Fatec Rubens Lara - Santos, São Paulo",
          ],
          [
            "JAN 2023 - JUL 2023 (TRANCADO)",
            "Tecnólogo em Sistemas Para Internet",
            "Fatec Rubens Lara - Santos, São Paulo",
          ],
        ].map(([date, course, school]) => (
          <article
            key={school + course}
            className="flex flex-col gap-2 border-b border-dashed border-[#ababab]/30 pb-10 last:border-b-0 last:pb-0"
          >
            <p className="about-reveal scroll-reveal font-['IBM_Plex_Mono:Regular'] text-xs text-[#ababab]">
              {date}
            </p>
            <h3 className="about-reveal scroll-reveal text-xl text-[#faf9f6]">
              {course}
            </h3>
            <p className="about-reveal scroll-reveal">{school}</p>
          </article>
        ))}
      </section>

      <div className="h-px bg-[#ababab]/30" />


<section className="flex flex-col gap-6">
  <h2 className="about-reveal scroll-reveal font-['Instrument_Serif:Regular'] text-[32px] text-[#faf9f6]">
    Certificações
  </h2>
  {[
    [
      "Google",
      {
        nome: "Build Wireframes and Low-Fidelity Prototypes",
        link: "https://coursera.org/share/31cd5393d0a6ca63544388c2069782b5",
      },
      {
        nome: "Conduct UX Research and Test Early Concepts",
        link: "https://coursera.org/share/8f3b5198aad4789d4499065aeb531680",
      },
      {
        nome: "Foundations of User Experience (UX) Design",
        link: "https://coursera.org/share/b99c50403f5a6e14e2dc2f7f3dad0f66",
      },
      {
        nome: "Start the UX Design Process: Empathize, Define, and Ideate",
        link: "https://coursera.org/share/42bc96c0ab0bee7c222b4040e18a72eb",
      },
      {
        nome: "Foundations of Project Management",
        link: "https://www.coursera.org/account/accomplishments/verify/XKAVMDC4GAG9",
      },
      {
        nome: "Project Initiation: Starting a Successful Project",
        link: "https://www.coursera.org/account/accomplishments/certificate/5E5PRV9AEUJB",
      },
      {
        nome: "Project Planning: Putting It All Together",
        link: "https://www.coursera.org/account/accomplishments/certificate/GNYFDS5M4HLY",
      },
    ],
    [
      "Fundação Bradesco",
      "Desenvolvimento Orientado a Objetos Utilizando Python",
      "Introdução à Análise de Dados – Microsoft Power BI",
      "Introdução à Programação Orientada a Objetos (POO)",
      "Linguagem de Programação Python – Básico",
    ],
    [
      "Alura",
      {
        nome: "Git e GitHub: compartilhando e colaborando em projetos",
        link: "https://cursos.alura.com.br/certificate/vinicius-florencio/git-github-compartilhando-colaborando-projetos",
      },
      {
        nome: "WordPress: crie sites com Elementor e Figma",
        link: "https://cursos.alura.com.br/certificate/vinicius-florencio/wordpress-crie-sites-elementor-figma",
      },
      {
        nome: "WordPress: integrando responsividade, efeitos visuais e explorando plugins",
        link: "https://cursos.alura.com.br/certificate/vinicius-florencio/wordpress-responsividade-efeitos-visuais-plugins",
      },
      {
        nome: "Formação A partir do zero: HTML e CSS para projetos web",
        link: "https://cursos.alura.com.br/degree/certificate/6fad05a6-428f-4802-814a-b504798fe110",
      },
      {
        nome: "Microsoft SQL Server 2022: conhecendo SQL",
        link: "https://cursos.alura.com.br/certificate/55a2b96e-d74c-446f-b1ae-df4dd0dc9984?lang=pt_BR",
      },
      {
        nome: "Power BI Desktop: Construindo meu primeiro Dashboard",
        link: "https://cursos.alura.com.br/certificate/4dafe42f-d74d-4dd6-a95d-66c4b19f444b",
      },
      {
        nome: "C: Avançando na Linguagem",
        link: "https://cursos.alura.com.br/certificate/28ec5aa1-4956-4018-8b3c-fe5a2101cfae",
      },
      {
        nome: "C: Conhecendo a Linguagem das Linguagens",
        link: "https://cursos.alura.com.br/certificate/f4d18c10-77bc-445c-a1dc-dddae4295636",
      },
      {
        nome: "Bootstrap 5: crie uma landing page responsiva",
        link: "https://cursos.alura.com.br/user/vinicius-florencio/course/bootstrap5-landing-page-responsiva/certificate",
      },
      {
        nome: "Cores no design: teoria e prática",
        link: "https://cursos.alura.com.br/certificate/vinicius-florencio/cores-design-teoria-pratica",
      },
      {
        nome: "Design Visual: aplicando técnicas de composição",
        link: "https://cursos.alura.com.br/user/vinicius-florencio/course/design-visual-aplicando-tecnicas-composicao/certificate",
      },
      {
        nome: "Design Visual: estratégias para planejar e construir seu portfólio",
        link: "https://cursos.alura.com.br/certificate/vinicius-florencio/design-entenda-conheca-area",
      },
      {
        nome: "Design: entenda e conheça a área",
        link: "https://cursos.alura.com.br/certificate/vinicius-florencio/design-entenda-conheca-area",
      },
      {
        nome: "Figma: componentes, auto layout e máscaras",
        link: "https://cursos.alura.com.br/user/vinicius-florencio/course/figma-componentes-auto-layout-mascaras/certificate",
      },
      {
        nome: "Figma: conhecendo a ferramenta",
        link: "https://cursos.alura.com.br/user/vinicius-florencio/course/figma-conhecendo-ferramenta/certificate",
      },
      {
        nome: "Grids: como organizar o conteúdo visual",
        link: "https://cursos.alura.com.br/user/vinicius-florencio/course/grids-organizar-conteudo-visual/certificate",
      },
      {
        nome: "Tipografia: conceitos e prática",
        link: "https://cursos.alura.com.br/user/vinicius-florencio/course/tipografia-conceitos-pratica/certificate",
      },
      {
        nome: "UI Design: melhorando a experiência de um app com UI Patterns",
        link: "https://cursos.alura.com.br/user/vinicius-florencio/course/ui-design-experiencia-app-ui-patterns/certificate",
      },
    ],
    [
      "Outros",
      "AZ-900 Microsoft Azure Fundamentals - Fundação FAT",
      "EF SET English Certificate – Score 78/100 (C2 Proficient)",
    ],
  ].map(([provider, ...items]) => (
    <article
      key={provider}
      className="flex flex-col gap-3 border-b border-dashed border-[#ababab]/30 pb-6 last:border-b-0 last:pb-0"
    >
      <h3 className="about-reveal scroll-reveal text-xl text-[#faf9f6]">
        {provider}
      </h3>
      <ul className="list-outside list-disc space-y-1 pl-6 leading-[27px] marker:text-[#ababab]">
        {items.map((item, index) => {
          const nome = typeof item === "string" ? item : item.nome;
          const link = typeof item === "string" ? undefined : item.link;

          return (
            <li
              key={nome}
              className="about-reveal scroll-reveal"
              style={{ transitionDelay: `${index * 70}ms` }}
            >
              {link ? (
                <a
                  href={link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline decoration-[#ababab]/40 underline-offset-4 transition-colors hover:text-white hover:decoration-white"
                >
                  {nome}
                </a>
              ) : (
                nome
              )}
            </li>
          );
        })}
      </ul>
    </article>
  ))}
</section>

    </div>
  )
}

export default function App() {
  const [pageView, setPageView] = useState<PageView>("portfolio")
  const [openMenu, setOpenMenu] = useState<MenuName | null>(null)
  const [contentView, setContentView] = useState<ContentView>("projects")
  const [mobileSideNavOpen, setMobileSideNavOpen] = useState(false)
  const [projectsNavVisible, setProjectsNavVisible] = useState(false)
  const [footerVisible, setFooterVisible] = useState(false)
  const portraitRef = useRef<HTMLDivElement>(null)
  const homeHeroRef = useRef<HTMLDivElement>(null)
  const homeScrollLockRef = useRef<number | null>(null)
  const projectsScrollLockRef = useRef<number | null>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible")
          } else {
            entry.target.classList.remove("is-visible")
          }
        })
      },
      { threshold: 0.2, rootMargin: "0px 0px -45% 0px" },
    )

    document
      .querySelectorAll(".scroll-reveal, .skill-reveal")
      .forEach((element) => observer.observe(element))

    const projectsSection = document.getElementById("projetos")
    const projectsObserver = new IntersectionObserver(
      ([entry]) => {
        setProjectsNavVisible(entry.isIntersecting)
        if (!entry.isIntersecting) setMobileSideNavOpen(false)
      },
      { threshold: 0.02 },
    )

    if (projectsSection) projectsObserver.observe(projectsSection)

    const footer = document.getElementById("contatos")
    const footerObserver = new IntersectionObserver(
      ([entry]) => {
        setFooterVisible(entry.isIntersecting)
        if (entry.isIntersecting) setMobileSideNavOpen(false)
      },
      { threshold: 0.08 },
    )

    if (footer) footerObserver.observe(footer)

    const updateHomeVisibility = () => {
      if (!homeHeroRef.current) return

      const progress = Math.min(
        Math.max(window.scrollY / (window.innerHeight * 0.72), 0),
        1,
      )

      homeHeroRef.current.style.opacity = String(1 - progress)
      homeHeroRef.current.style.transform = `translateY(${-24 * progress}px)`
      homeHeroRef.current.style.pointerEvents = progress > 0.9 ? "none" : "auto"
    }

    window.addEventListener("scroll", updateHomeVisibility, { passive: true })
    updateHomeVisibility()

    return () => {
      observer.disconnect()
      projectsObserver.disconnect()
      footerObserver.disconnect()
      window.removeEventListener("scroll", updateHomeVisibility)
    }
  }, [pageView])

  const toggleMenu = (menu: MenuName) => {
    setOpenMenu((current) => (current === menu ? null : menu))
  }

  const switchContent = (view: ContentView) => {
    setPageView("portfolio")
    setContentView(view)
    setOpenMenu(null)
    setMobileSideNavOpen(false)
    document
      .getElementById("projetos")
      ?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  const openMovecta = () => {
    setOpenMenu(null)
    setPageView("movecta")
    window.scrollTo({ top: 0 })
  }

  const movePortrait = (event: React.PointerEvent<HTMLElement>) => {
    if (
      !portraitRef.current ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    )
      return

    const x = event.clientX / window.innerWidth - 0.5
    const y = event.clientY / window.innerHeight - 0.5

    portraitRef.current.style.transform = `perspective(900px) rotateX(${-y * 10}deg) rotateY(${x * 10}deg) scale(1.015)`
  }

  const resetPortrait = () => {
    if (portraitRef.current) {
      portraitRef.current.style.transform =
        "perspective(900px) rotateX(0deg) rotateY(0deg) scale(1)"
    }
  }

  const scrollHomeToProjects = (event: React.WheelEvent<HTMLElement>) => {
    if (event.deltaY <= 0) return

    event.preventDefault()
    if (homeScrollLockRef.current !== null) return

    homeScrollLockRef.current = window.setTimeout(() => {
      document
        .getElementById("projetos")
        ?.scrollIntoView({ behavior: "smooth", block: "start" })

      homeScrollLockRef.current = window.setTimeout(() => {
        homeScrollLockRef.current = null
      }, 800)
    }, 120)
  }

  const scrollProjectsToHome = (event: React.WheelEvent<HTMLElement>) => {
    const projectsTop = event.currentTarget.offsetTop
    if (event.deltaY >= 0 || window.scrollY > projectsTop + 4) return

    event.preventDefault()
    if (projectsScrollLockRef.current !== null) return

    projectsScrollLockRef.current = window.setTimeout(() => {
      window.scrollTo({ top: 0, behavior: "smooth" })

      projectsScrollLockRef.current = window.setTimeout(() => {
        projectsScrollLockRef.current = null
      }, 800)
    }, 120)
  }

  if (pageView === "movecta") {
    return (
      <Movecta
        onShowProjects={(projectId) => {
          setPageView("portfolio")
          setContentView("projects")
          window.setTimeout(() => {
            document
              .getElementById(projectId || "projetos")
              ?.scrollIntoView({ behavior: "smooth", block: "start" })
          }, 0)
        }}
        onShowAbout={() => {
          setPageView("portfolio")
          setContentView("about")
          window.scrollTo({ top: window.innerHeight })
        }}
        onGoHome={() => {
          setPageView("portfolio")
          setContentView("projects")
          window.scrollTo({ top: 0, behavior: "instant" })
        }}
      />
    )
  }

  return (
    <div className="bg-[#1c1c1c] text-[#c4c4c4]">
      <main
        className="page-grid relative min-h-dvh snap-start content-center overflow-hidden bg-[#1c1c1c] py-10 text-[#c4c4c4] max-md:overflow-y-auto"
        onPointerMove={movePortrait}
        onPointerLeave={resetPortrait}
        onWheel={scrollHomeToProjects}
      >
        <Header
          onOpenMovecta={openMovecta}
          onShowAbout={() => switchContent("about")}
          onShowProjects={(projectId) => {
            switchContent("projects")
        
            if (projectId) {
              window.setTimeout(() => {
                document
                  .getElementById(projectId)
                  ?.scrollIntoView({ behavior: "smooth" })
              }, 0)
            }
          }}
          onGoHome={() => {
            setPageView("portfolio")
            setContentView("projects")
            window.scrollTo({ top: 0, behavior: "smooth" })
          }}
        />

        <MobileMenu
          variant="home"
          onOpenMovecta={openMovecta}
          onShowProjects={(projectId) => {
            switchContent("projects")
        
            if (projectId) {
              window.setTimeout(() => {
                document
                  .getElementById(projectId)
                  ?.scrollIntoView({ behavior: "smooth" })
              }, 0)
            }
          }}
          onShowAbout={() => switchContent("about")}
        />
        
        <div
          ref={homeHeroRef}
          id="inicio"
          className="home-hero relative col-start-3 col-end-11 flex items-center justify-between max-lg:col-start-2 max-lg:col-end-12 max-md:flex-col-reverse max-md:gap-7"
        >
          <div className="flex w-[586px] min-w-0 flex-col gap-6 max-md:w-full">
            <div className="flex flex-col gap-3">
              <p
                className="home-fade-item hero-eyebrow fade-in font-['IBM_Plex_Mono:Medium'] text-xs text-[#ababab]"
                style={{ animationDelay: "360ms" }}
              >
                PRODUCT DESIGN • DESIGN SYSTEM • WCAG 2.2 • RESEARCH • AI
              </p>
              <h1
                className="home-fade-item hero-title fade-in font-['Instrument_Serif:Regular'] text-[80px] leading-none whitespace-nowrap text-[#faf9f6] max-lg:text-[clamp(3.2rem,6vw,5rem)] max-sm:text-5xl max-sm:whitespace-normal"
                style={{ animationDelay: "500ms" }}
              >
                Vinicius Florencio
              </h1>
              <p
                className="home-fade-item hero-description fade-in font-['Satoshi_Variable:Regular'] text-xl leading-[27px] text-[#c4c4c4] max-sm:text-lg max-sm:leading-6"
                style={{ animationDelay: "640ms" }}
              >
                Product Designer Jr., analista de sistemas, santista e
                voluntário com 2+ anos de experiência no desenvolvimento de
                soluções focadas no usuário
              </p>
            </div>
            <div
              className="home-fade-item hero-links fade-in flex items-center gap-10 max-sm:flex-wrap max-sm:gap-x-6 max-sm:gap-y-3"
              style={{ animationDelay: "780ms" }}
            >
              <ArrowLink href="https://www.linkedin.com">LINKEDIN</ArrowLink>
              <ArrowLink href="mailto:vinicius@example.com">E-MAIL</ArrowLink>
              <ArrowLink href="https://wa.me/">WHATSAPP</ArrowLink>
              <ArrowLink href="#cv">CV</ArrowLink>
            </div>
          </div>

          <div
            className="home-fade-item hero-image fade-in size-[300px] shrink-0 max-md:size-[min(220px,58vw)]"
            style={{ animationDelay: "420ms" }}
          >
            <div
              ref={portraitRef}
              className="portrait-parallax size-full bg-gradient-to-b from-[#242424] to-[#262626] p-2 shadow-[0_4px_4px_rgba(0,0,0,0.12)]"
            >
              <div className="size-full overflow-hidden">
                <img
                  className="aspect-square h-auto w-full object-cover"
                  src={`${assetPathPrefix}/e4019.png`}
                  alt="Retrato de Vinicius Florencio"
                />
              </div>
            </div>
          </div>

          <div className="absolute top-[calc(100%+120px)] left-1/2 -translate-x-1/2 max-md:top-[calc(100%+88px)]">
            <button
              type="button"
              onClick={() =>
                document
                  .getElementById("projetos")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="home-fade-item hero-scroll-cue fade-in-up group flex items-center gap-2 font-['IBM_Plex_Mono:SemiBold'] text-sm whitespace-nowrap text-[#ababab] transition-colors hover:text-[#faf9f6] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#faf9f6]"
            >
              <img
                className="scroll-cue-icon size-6"
                src={`${assetPathPrefix}/b8771.svg`}
                alt=""
              />
              VER MAIS
            </button>
          </div>
        </div>
      </main>

      <section
        id="projetos"
        className="page-grid relative min-h-dvh snap-start scroll-mt-0 bg-[#1c1c1c] pt-32 max-md:pt-24"
        onWheel={scrollProjectsToHome}
      >
        <aside className="scroll-reveal sticky top-32 col-start-2 col-end-4 row-start-1 row-end-4 flex h-fit flex-col items-end gap-3 self-start text-right font-['IBM_Plex_Mono:SemiBold'] text-sm max-md:hidden">
          <button
            type="button"
            className={`transition-colors hover:text-[#faf9f6] ${
              contentView === "projects" ? "text-[#faf9f6]" : "text-[#ababab]"
            }`}
            onClick={() => switchContent("projects")}
          >
            PROJETOS
          </button>
          <button
            type="button"
            className={`transition-colors hover:text-[#faf9f6] ${
              contentView === "about" ? "text-[#faf9f6]" : "text-[#ababab]"
            }`}
            onClick={() => switchContent("about")}
          >
            SOBRE MIM
          </button>
        </aside>

        <div
          className={`fixed bottom-[120px] left-0 z-40 transition-transform duration-500 ease-out md:hidden ${
            projectsNavVisible && !footerVisible
              ? "translate-x-0"
              : "pointer-events-none -translate-x-full"
          }`}
          aria-hidden={!projectsNavVisible || footerVisible}
        >
          <nav
            aria-label="Navegação lateral"
            aria-hidden={!mobileSideNavOpen}
            className={`absolute bottom-0 left-[calc(100%-1px)] flex w-max flex-col items-end gap-3 bg-gradient-to-b from-[#242424] to-[#262626] p-3 text-right font-['IBM_Plex_Mono:SemiBold'] text-sm shadow-[0_4px_4px_rgba(0,0,0,0.12)] transition-transform duration-300 ease-out ${
              mobileSideNavOpen
                ? "translate-x-0"
                : "pointer-events-none -translate-x-full"
            }`}
          >
            <button
              type="button"
              className={
                contentView === "projects"
                  ? "text-[#faf9f6]"
                  : "text-[#ababab]"
              }
              onClick={() => switchContent("projects")}
            >
              PROJETOS
            </button>
            <button
              type="button"
              className={
                contentView === "about"
                  ? "text-[#faf9f6]"
                  : "text-[#ababab]"
              }
              onClick={() => switchContent("about")}
            >
              SOBRE MIM
            </button>
          </nav>

          <button
            type="button"
            className="relative flex flex-col items-center gap-3 bg-gradient-to-b from-[#242424] to-[#262626] p-3 font-['IBM_Plex_Mono:SemiBold'] text-sm text-[#faf9f6] shadow-[0_4px_4px_rgba(0,0,0,0.12)]"
            aria-label={
              mobileSideNavOpen
                ? "Fechar navegação lateral"
                : "Abrir navegação lateral"
            }
            aria-expanded={mobileSideNavOpen}
            onClick={() => setMobileSideNavOpen((current) => !current)}
          >
            <span className="flex size-5 items-center justify-center">
              <img src={`${assetPathPrefix}/283c3.svg`} alt="" />
            </span>
            <span className="block rotate-180 [writing-mode:vertical-rl]">
              NAVEGAÇÃO
            </span>
          </button>
        </div>

        <div className="relative col-start-4 col-end-12 row-start-1 max-md:col-start-2">
          <div
            className={`grid grid-cols-2 gap-6 max-md:grid-cols-1 ${
              contentView === "projects" ? "" : "hidden"
            }`}
          >
            {projects.map((project, index) => (
              <ProjectCard
                key={project.id}
                project={project}
                delay={(index + 1) * 300}
                onOpen={project.id === "movecta" ? openMovecta : undefined}
              />
            ))}
          </div>
          <div
            id="sobre"
            className={`bg-[#1c1c1c] font-['Satoshi_Variable:Regular'] text-[#c4c4c4] ${
              contentView === "about" ? "" : "hidden"
            }`}
          >
            <AboutContent />
          </div>
        </div>

        <div className="scroll-reveal relative col-start-4 col-end-12 row-start-2 mt-20 h-px overflow-hidden bg-[#ababab]/30 max-md:col-start-2 max-md:mt-12">
          <img
            className="absolute top-0 left-0 max-w-none"
            src={`${assetPathPrefix}/1d76e.svg`}
            alt=""
          />
        </div>
        <Footer className="!pt-12 max-md:!pt-8" />
      </section>
    </div>
  )
}
