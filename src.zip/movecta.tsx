import { useEffect, useLayoutEffect, useRef, useState } from "react"
import AnimatedNumber from "../components/animatedNumber"
import SectionTitle from "../components/sectionTitle"
import StatGrid from "../components/statGrid"
import ProjectImage from "../components/projectImage"
import Timeline from "../components/timeline"
import BenchmarkTable from "../components/benchmarkTable"
import Divider from "../components/divider"
import Footer from "../components/footer"
import Header from "../components/header"
import MobileMenu from "../components/mobileMenu"

const assetPathPrefix = "/assets"

const sectionNav = [
  ["movecta-inicio", "INÍCIO"],
  ["movecta-papel", "MEU PAPEL"],
  ["movecta-desafio", "DESAFIO"],
  ["movecta-pesquisa", "PESQUISA COM USUÁRIOS"],
  ["movecta-afinidade", "MAPA DE AFINIDADE"],
  ["movecta-heuristica", "AVALIAÇÃO HEURÍSTICA"],
  ["movecta-benchmarking", "BENCHMARKING"],
  ["movecta-inventario", "INVENTÁRIO DE RECURSOS"],
  ["movecta-prototipacao", "PROTOTIPAÇÃO"],
  ["movecta-testes", "TESTES DE USABILIDADE"],
] as const

const dividerAssets = [
  "afc1b.svg",
  "9f302.svg",
  "cabc8.svg",
  "5c1cf.svg",
  "41269.svg",
  "cb483.svg",
  "c34a9.svg",
  "f0c0c.svg",
  "103b7.svg",
  "e4fb4.svg",
]

const benchmarkRows = [
  ["Portal atual", true, true, true, true, true],
  ["DP World", true, true, true, true, true],
  ["Ecoporto", true, true, true, false, true],
  ["Sita", true, true, true, true, false],
  ["Bandeirantes Deicmar", true, true, true, true, true],
  ["Tecon", false, false, true, false, true],
] as const

export default function MovectaProject({
  onShowAbout,
  onShowProjects,
  onGoHome,
}: {
  onShowAbout: () => void
  onShowProjects: (projectId?: string) => void
  onGoHome: () => void
}) {
  const [activeSection, setActiveSection] = useState("movecta-inicio")
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const [footerVisible, setFooterVisible] = useState(false)

  useLayoutEffect(() => {
    const sections = sectionNav
      .map(([id]) => document.getElementById(id))
      .filter(Boolean) as HTMLElement[]
    const observer = new IntersectionObserver(
      (entries) => {
        const current = entries.find((entry) => entry.isIntersecting)
        if (current) setActiveSection(current.target.id)
      },
      { rootMargin: "-15% 0px -70% 0px" },
    )
    sections.forEach((section) => observer.observe(section))

    const revealItems = document.querySelectorAll(
      "#movecta-page main :is(h1,h2,h3,p,li,blockquote,img,th,td), #movecta-contatos :is(h2,p,a)",
    )
    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) =>
          entry.target.classList.toggle("is-visible", entry.isIntersecting),
        )
      },
      { threshold: 0.12, rootMargin: "0px 0px -12% 0px" },
    )
    revealItems.forEach((item) => {
      item.classList.add("case-reveal")
      revealObserver.observe(item)
    })

    const footer = document.getElementById("movecta-contatos")
    const footerObserver = new IntersectionObserver(
      ([entry]) => {
        setFooterVisible(entry.isIntersecting)
        if (entry.isIntersecting) setMobileNavOpen(false)
      },
      { threshold: 0.05 },
    )
    if (footer) footerObserver.observe(footer)

    return () => {
      observer.disconnect()
      revealObserver.disconnect()
      footerObserver.disconnect()
    }
  }, [])

  const scrollTo = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })

  return (
    <div
      id="movecta-page"
      className="min-h-dvh bg-[#1c1c1c] font-['Satoshi_Variable:Regular'] text-[#c4c4c4]"
    >
        <Header
          onOpenMovecta={() => scrollTo("movecta-inicio")}
          onShowAbout={onShowAbout}
          onShowProjects={onShowProjects}
          onGoHome={onGoHome}
        />
        
        <MobileMenu
          variant="movecta"
          onOpenMovecta={() => scrollTo("movecta-inicio")}
          onShowProjects={onShowProjects}
          onShowAbout={onShowAbout}
          onScrollTo={scrollTo}
        />

      <main className="page-grid items-start pt-32 max-md:pt-24">
        <aside className="sticky top-32 col-start-2 col-end-4 row-start-1 row-end-3 flex h-fit flex-col items-end gap-3 self-start text-right font-['IBM_Plex_Mono:SemiBold'] text-sm max-md:hidden">
          {sectionNav.map(([id, label]) => (
            <button
              key={id}
              type="button"
              className={`transition-colors hover:text-[#faf9f6] ${
                activeSection === id ? "text-[#faf9f6]" : "text-[#ababab]"
              }`}
              onClick={() => scrollTo(id)}
            >
              {label}
            </button>
          ))}
        </aside>

        <div className="col-start-4 col-end-12 row-start-1 flex min-w-0 flex-col gap-32 pb-20 max-md:col-start-2">
          <section
            id="movecta-inicio"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <ProjectImage
              file="29fa9.png"
              alt="Portal de Autoatendimento Movecta"
            />
            <div className="flex flex-col gap-3">
              <p className="font-['IBM_Plex_Mono:Medium'] text-xs text-[#ababab]">
                2025 • RESEARCH • LOGÍSTICA • B2B
              </p>
              <h1 className="font-['Instrument_Serif:Regular'] text-[32px] leading-none text-[#faf9f6]">
                Portal de Autoatendimento Movecta
              </h1>
            </div>
            <p className="text-xl leading-[27px]">
              Este case apresenta toda a jornada de discovery, entrevistas,
              desenvolvimento e testes do redesign de um portal de
              autoatendimento logístico, criado para facilitar as operações
              portuárias dos clientes de um terminal logístico.
            </p>
            <div className="grid grid-cols-4 gap-6 max-lg:grid-cols-2 max-sm:grid-cols-1">
              {[
                ["100%", "preferiram o novo fluxo"],
                ["15+ entrevistas", "usuários internos e externos"],
                ["+3.200h registradas", "5 meses de projeto"],
                ["2 frentes de trabalho", "negócios e design"],
              ].map(([value, label]) => (
                <div key={value}>
                  <p className="text-xl font-medium text-[#faf9f6]">
                    <AnimatedNumber value={value} />
                  </p>
                  <p className="leading-[27px]">{label}</p>
                </div>
              ))}
            </div>
          </section>

          <Divider />

          <section
            id="movecta-papel"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle>Meu papel</SectionTitle>
            <p className="leading-[27px]">
              Como designer de produto fui um dos responsáveis pela condução de
              entrevistas, análise de dados e geração de insights com auxílio
              de <strong className="font-medium">inteligência artificial</strong>,
              criação de protótipos navegáveis de alta fidelidade e condução de
              testes de usabilidade com usuários finais.
            </p>
            <h3 className="font-medium text-[#faf9f6]">Processo de design</h3>
            <p className="leading-[27px]">
              O processo de design seguiu os princípios do{" "}
              <strong className="font-medium">Design Thinking</strong>, buscando
              compreender profundamente as dores dos usuários e iterar
              continuamente na criação e validação de protótipos navegáveis.
            </p>
            <Timeline />
          </section>

          <Divider />

          <section
            id="movecta-desafio"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle>Desafio</SectionTitle>
            <p className="leading-[27px]">
              Os principais desafios do projeto foram reformular a experiência
              do cliente dentro do portal de autoatendimento logístico e reduzir
              a alta dependência de ferramentas externas como telefones e
              e-mails para contato com o operador do terminal.
            </p>
            <div className="grid grid-cols-2 gap-6 max-sm:grid-cols-1">
              <ProjectImage file="e4225.png" alt="Portal anterior, tela um" />
              <ProjectImage file="6ac05.png" alt="Portal anterior, tela dois" />
              <ProjectImage file="6eb7c.png" alt="Portal anterior, tela três" />
              <ProjectImage file="20509.png" alt="Portal anterior, tela quatro" />
            </div>
            <blockquote className="border-l border-[#ababab] pl-3 font-medium text-[#ababab]">
              “O portal do cliente atual não oferece uma boa usabilidade e
              carece de funcionalidades relevantes.”
            </blockquote>
          </section>

          <Divider />

          <section
            id="movecta-pesquisa"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle eyebrow="EMPATIA • SEMANAS 1 - 3">
              Pesquisa com usuários
            </SectionTitle>
            <p className="leading-[27px]">
              Iniciamos com a fase de pesquisa com usuários para entender a
              experiência atual como um todo, investigar a jornada e identificar
              frustrações e pontos de melhoria.
            </p>
            <h3 className="font-medium text-[#faf9f6]">Metodologia</h3>
            <StatGrid
              items={[
                ["14", "entrevistas com usuários"],
                ["17h", "de entrevistas qualitativas"],
                ["18", "pontos de dor"],
                ["24", "possibilidades de melhoria"],
              ]}
            />
            <h3 className="font-medium text-[#faf9f6]">Dados demográficos</h3>
            <p className="leading-[27px]">
              Com isso, conseguimos identificar os padrões demográficos dos
              usuários antes de aprofundar a análise dos dados coletados.
            </p>
            <StatGrid
              items={[
                ["38 anos", "idade média"],
                ["Ensino superior", "escolaridade predominante"],
                ["60% homens", "gênero predominante"],
                ["Intermediário", "letramento digital"],
              ]}
            />
          </section>

          <Divider />

          <section
            id="movecta-afinidade"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle eyebrow="DEFINIÇÃO • SEMANAS 1 - 3">
              Mapa de afinidade
            </SectionTitle>
            <p className="leading-[27px]">
              Após a primeira rodada de entrevista, com um grande volume de
              dados, pudemos montar um mapa de afinidade que gerou evidências
              sólidas dos principais pontos de dor dos usuários.
            </p>
            <ProjectImage file="1eca9.png" alt="Mapa de afinidade do projeto" />
            <h3 className="font-medium text-[#faf9f6]">
              Principais descobertas
            </h3>
            <div className="grid grid-cols-3 gap-6 max-lg:grid-cols-1">
              {[
                [
                  "Falta de visibilidade de status",
                  ["A carga está liberada?", "Existe algum bloqueio? Por quê?", "Em qual etapa está o processo?"],
                  "“Ficamos o tempo inteiro às cegas.”",
                ],
                [
                  "Comunicação complexa e reativa",
                  ["Informações críticas chegam tarde", "Falta de alertas automáticos", "Excesso de e-mails"],
                  "“Recebo cerca de 60 e-mails por dia.”",
                ],
                [
                  "Informações fragmentadas",
                  ["Relatórios pouco legíveis", "Falta de visão consolidada", "Dificuldade de tomada de decisão"],
                  "“Não existe uma tela que une tudo.”",
                ],
              ].map(([title, items, quote]) => (
                <article key={title as string} className="flex flex-col gap-3">
                  <h3 className="font-medium text-[#faf9f6]">{title}</h3>
                  <ul className="list-disc pl-6 leading-[27px]">
                    {(items as string[]).map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                  <blockquote className="border-l border-[#ababab] pl-3 font-medium text-[#ababab]">
                    {quote}
                  </blockquote>
                </article>
              ))}
            </div>
          </section>

          <Divider />

          <section
            id="movecta-heuristica"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle eyebrow="EMPATIA • SEMANA 3">
              Avaliação heurística
            </SectionTitle>
            <p className="leading-[27px]">
              Também avaliamos o portal antigo com base nas 10 heurísticas de
              Nielsen para identificar problemas de usabilidade e
              inconsistências na interface, orientando as decisões de UX para o
              novo portal.
            </p>
            <h3 className="font-medium text-[#faf9f6]">Descobertas</h3>
            <StatGrid
              items={[
                ["19", "problemas identificados"],
                ["5", "alto impacto"],
                ["11", "médio impacto"],
                ["3", "baixo impacto"],
              ]}
            />
          </section>

          <Divider />

          <section
            id="movecta-benchmarking"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle eyebrow="IDEAÇÃO • SEMANAS 4 - 5">
              Benchmarking
            </SectionTitle>
            <p className="leading-[27px]">
              Realizamos um benchmarking competitivo para mapear funcionalidades
              e soluções adotadas por portais similares, incluindo referências
              sugeridas pelo time interno.
            </p>
            <p className="leading-[27px]">
              Além de analisar as interfaces e os fluxos de navegação, estudamos
              a documentação técnica dos concorrentes para compreender melhor o
              funcionamento de seus recursos e suas possíveis aplicações.
            </p>
            <BenchmarkTable />
            <p className="leading-[27px]">
              A partir dessa análise, avaliamos quais funcionalidades faziam
              sentido incorporar à nossa proposta, considerando as necessidades
              dos usuários, a viabilidade técnica e o contexto do negócio.
            </p>
          </section>

          <Divider />

          <section
            id="movecta-inventario"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle eyebrow="IDEAÇÃO • SEMANA 6">
              Inventário de recursos
            </SectionTitle>
            <p className="leading-[27px]">
              Mapeamos as funcionalidades existentes no portal para compreender
              sua estrutura, identificar oportunidades de melhoria e orientar o
              redesign.
            </p>
            <ProjectImage
              file="e342b.png"
              alt="Inventário de recursos do portal"
            />
          </section>

          <Divider />

          <section
            id="movecta-prototipacao"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle eyebrow="PROTOTIPAÇÃO • SEMANAS 4 - 8">
              Prototipação
            </SectionTitle>
            <p className="leading-[27px]">
              Com os dados limpos e insights consolidados iniciamos a fase de
              prototipação, gerando artefatos palpáveis que traduziram o
              trabalho da equipe de design em uma experiência interativa que
              abrange cerca de <strong className="font-medium">20 fluxos de trabalho</strong>.
              Também incorporamos um <strong className="font-medium">chat integrado</strong>{" "}
              em todas as telas, centralizando a comunicação e reduzindo a
              dependência de canais externos.
            </p>
            <ProjectImage file="bac8e.png" alt="Visão geral dos fluxos do portal" />
            <h3 className="font-medium text-[#faf9f6]">Objetivos</h3>
            <div className="grid grid-cols-3 gap-6 max-sm:grid-cols-1">
              {[
                "Redução de retrabalho operacional",
                "Maior previsibilidade para os usuários",
                "Comunicação proativa",
                "Visibilidade e clareza",
                "Acompanhamento contínuo da operação",
              ].map((objective) => (
                <p
                  key={objective}
                  className="bg-gradient-to-b from-[#242424] to-[#262626] p-3 leading-[27px] shadow-[0_4px_4px_rgba(0,0,0,0.12)]"
                >
                  {objective}
                </p>
              ))}
            </div>
            <h3 className="font-medium text-[#faf9f6]">Fluxos</h3>
            {[
              [
                "Login:",
                "Redesenhamos o fluxo de autenticação com suporte à certificação digital e uma experiência de primeiro acesso renovada, buscando simplificar a entrada na plataforma e facilitar o entendimento das etapas necessárias para acessar o portal.",
                "ae9eb.png",
              ],
              [
                "Dashboard inicial:",
                "Desenvolvemos uma tela inicial que reúne as principais informações e funcionalidades do portal, facilitando o acesso às tarefas recorrentes e oferecendo uma visão geral das operações sem a necessidade de navegar por diferentes áreas.",
                "ef28d.png",
              ],
              [
                "Acompanhamento de carga:",
                "Projetamos uma tela que consolida o histórico completo de movimentações da carga, reunindo informações como temperatura, anexos, registros de avarias e demais dados operacionais em um único ambiente. O objetivo foi facilitar o acompanhamento da operação e reduzir a fragmentação das informações.",
                "39b91.png",
              ],
              [
                "Agendamentos:",
                "Redesenhamos a experiência de agendamento com uma interface mais visual e três modos de visualização: diária, semanal e mensal. Também propusemos uma funcionalidade de encaixe de agendamentos diretamente pela plataforma.",
                "2283d.png",
              ],
            ].map(([title, description, image], index) => (
              <div key={title} className="flex flex-col gap-6">
                {index > 0 && (
                  <img
                    className="block h-px w-full"
                    src={`${assetPathPrefix}/1c018.svg`}
                    alt=""
                  />
                )}
                <p className="leading-[27px]">
                  <strong className="font-medium">{title}</strong> {description}
                </p>
                <ProjectImage file={image} alt={`Fluxo de ${title}`} />
              </div>
            ))}
            <h3 className="font-medium text-[#faf9f6]">Dark mode</h3>
            <p className="leading-[27px]">
              O portal foi projetado considerando princípios de acessibilidade
              da <strong className="font-medium">WCAG 2.2</strong>, buscando
              tornar a experiência mais inclusiva e facilitar a navegação.
              Também incorporamos opções de personalização entre os temas claro
              e escuro.
            </p>
            <div className="grid grid-cols-2 gap-6 max-sm:grid-cols-1">
              <ProjectImage file="bcdb7.png" alt="Portal em modo claro" />
              <ProjectImage file="79017.png" alt="Portal em modo escuro" />
              <ProjectImage file="bd92c.png" alt="Detalhe do modo claro" />
              <ProjectImage file="6e2f1.png" alt="Detalhe do modo escuro" />
            </div>
          </section>

          <Divider />

          <section
            id="movecta-testes"
            className="scroll-mt-32 flex flex-col gap-6"
          >
            <SectionTitle eyebrow="TESTES • SEMANAS 6 - 8">
              Testes de usabilidade
            </SectionTitle>
            <p className="leading-[27px]">
              Por fim realizamos uma nova rodada de entrevistas com testes
              moderados no <strong className="font-medium">Teams</strong> e não
              moderados no <strong className="font-medium">Maze</strong> para
              validar se a solução abordou os problemas da fase exploratória e
              identificar novos pontos de melhoria.
            </p>
            <h3 className="font-medium text-[#faf9f6]">Resultados</h3>
            <div className="grid grid-cols-2 gap-6 max-sm:grid-cols-1">
              {[
                ["Tracking completo aumenta a percepção de controle", "100%", "dos participantes compreenderam facilmente a funcionalidade e afirmaram que o novo fluxo melhoraria a qualidade e a eficiência da operação."],
                ["Relatórios personalizáveis reduzem o tempo de análise", "80%", "acreditam que relatórios personalizáveis e favoritos facilitariam a análise, a tomada de decisões e a prevenção de problemas."],
                ["Notificações em tempo real agilizam a operação", "80%", "relataram que alertas sobre movimentações permitiriam agir com mais agilidade, evitando atrasos em pagamentos, envios de documentos e acompanhamento das cargas."],
                ["Flexibilidade de agendamento reduz atritos", "80%", "relataram que a possibilidade de escolher datas e editar retiradas aumentaria a autonomia e reduziria a necessidade de contato direto com o operador."],
              ].map(([title, value, text]) => (
                <article
                  key={title}
                  className="bg-gradient-to-b from-[#242424] to-[#262626] p-3 shadow-[0_4px_4px_rgba(0,0,0,0.12)]"
                >
                  <h3 className="mb-3 text-xl font-medium text-[#faf9f6]">
                    {title}
                  </h3>
                  <p className="leading-[27px]">
                    <strong className="font-medium">{value}</strong> {text}
                  </p>
                </article>
              ))}
            </div>
          </section>

          <Divider />
        </div>
        <Footer />
      </main>

      <div
        className={`fixed bottom-[120px] left-0 z-40 transition-transform duration-500 ease-out md:hidden ${
          footerVisible
            ? "pointer-events-none -translate-x-full"
            : "translate-x-0"
        }`}
        aria-hidden={footerVisible}
      >
        <nav
          aria-label="Navegação do projeto"
          aria-hidden={!mobileNavOpen}
          className={`absolute bottom-0 left-[calc(100%-1px)] flex max-h-[70vh] w-[min(76vw,320px)] flex-col items-end gap-3 overflow-y-auto bg-gradient-to-b from-[#242424] to-[#262626] p-4 text-right font-['IBM_Plex_Mono:SemiBold'] text-xs shadow-[0_4px_4px_rgba(0,0,0,0.12)] transition-transform duration-300 ease-out ${
            mobileNavOpen
              ? "translate-x-0 opacity-100"
              : "pointer-events-none invisible -translate-x-full opacity-0"
          }`}
        >
          {sectionNav.map(([id, label]) => (
            <button
              key={id}
              type="button"
              className={
                activeSection === id ? "text-[#faf9f6]" : "text-[#ababab]"
              }
              onClick={() => {
                scrollTo(id)
                setMobileNavOpen(false)
              }}
            >
              {label}
            </button>
          ))}
        </nav>
        <button
          type="button"
          className="relative flex flex-col items-center gap-3 bg-gradient-to-b from-[#242424] to-[#262626] p-3 font-['IBM_Plex_Mono:SemiBold'] text-sm text-[#faf9f6] shadow-[0_4px_4px_rgba(0,0,0,0.12)]"
          aria-label={
            mobileNavOpen
              ? "Fechar navegação do projeto"
              : "Abrir navegação do projeto"
          }
          aria-expanded={mobileNavOpen}
          onClick={() => setMobileNavOpen((current) => !current)}
        >
          <span className="flex size-5 items-center justify-center">
            <img src={`${assetPathPrefix}/283c3.svg`} alt="" />
          </span>
          <span className="block rotate-180 [writing-mode:vertical-rl]">
            NAVEGAÇÃO
          </span>
        </button>
      </div>
    </div>
  )
}